package hust.soict.dsai.test.disc;
import hust.soict.dsai.aims.media.DigitalVideoDisc;

public class swap_object_2 {
	DigitalVideoDisc c;
	public swap_object_2(DigitalVideoDisc c) {
		this.c = c;
	}
}